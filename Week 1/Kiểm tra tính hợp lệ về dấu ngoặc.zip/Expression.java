public class Expression{
        class Node<E>{
        E element;
        Node next;
    }
    Node<Character> stack = null;
    int top = 0;
    Character[] steak = new Character[100];
    
    public void push(Character element){
        steak[top] = element;
        top++;
    }
    public Character pop(){
        top--;
        return steak[top];
    }
    public boolean isEmpty(){
        return top == 0;
    }
    
    public boolean isValidExpr(String expr)
    {
        for(int i  = 0; i < expr.length();i++){
            char c = expr.charAt(i);
            if(c == '('){
                push(c);
            }
            else if(c == ')'){
                if(isEmpty()){
                    return false;
                }
                pop();
            }
        }
        return isEmpty();
    }	 	  	      	    		  	    	    	 	
    
    
    public static void main(String[] args)
    {
        Expression expr = new Expression();
        String f = "a+b-c(3+a)";
        System.out.println(expr.isValidExpr(f));
        
    }

    
    
}