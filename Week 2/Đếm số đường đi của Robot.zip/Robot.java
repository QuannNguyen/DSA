//Sinh viên hoàn thành phương thức countPath(int M, int N, int t)
public class Robot {
	public int countPath(int M, int N, int t)
	{
		return -1;
	}
	
}
